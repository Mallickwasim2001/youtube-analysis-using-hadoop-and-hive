USvideos_updated<- read.csv("USvideos updated.csv")
str(USvideos_updated)
head(USvideos_updated)
anyNA(USvideos_updated)
USvideos_updated[, c("thumbnail_link", "description", "video_id", "tags")] <- NULL
youtube <- USvideos_updated[match(unique(USvideos_updated$title), USvideos_updated$title),]
install.packages("lubridate")
library(lubridate)
youtube$trending_date <- ydm(youtube$trending_date)
youtube$publish_time <- ymd_hms(youtube$publish_time)
youtube$category_id <- sapply(as.character(youtube$category_id), switch, 
                              "1" = "Film and Animation",
                              "2" = "Autos and Vehicles", 
                              "10" = "Music", 
                              "15" = "Pets and Animals", 
                              "17" = "Sports",
                              "18" = "Short Movies",
                              "19" = "Travel and Events", 
                              "20" = "Gaming", 
                              "22" = "People and Blogs", 
                              "23" = "Comedy",
                              "24" = "Entertainment", 
                              "25" = "News and Politics",
                              "26" = "Howto and Style", 
                              "27" = "Education",
                              "28" = "Science and Technology", 
                              "29" = "Nonprofit and Activism",
                              "43" = "Shows")
youtube[,c("views", "likes", "dislikes", "comment_count")] <- lapply(youtube[,c("views", "likes", "dislikes", "comment_count")], as.numeric)
youtube[,c("channel_title", "category_id")] <- lapply(youtube[,c("channel_title", "category_id")], as.factor)
youtube[,c("comments_disabled", "ratings_disabled", "video_error_or_removed")] <- lapply(youtube[,c("comments_disabled", "ratings_disabled", "video_error_or_removed")], as.logical)
str(youtube)
youtube$publish_hour <- hour(youtube$publish_time)
pw <- function(x){
  if(x < 8){
    x <- "12am to 8am"
  }else if(x >= 8 & x < 16){
    x <- "8am to 3pm"
  }else{
    x <- "3pm to 12am"
  }  
}
youtube$publish_when <- as.factor(sapply(youtube$publish_hour, pw))
youtube$publish_wday <- as.factor(weekdays(youtube$publish_time))

youtube$publish_wday <- ordered(youtube$publish_wday, levels=c("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"))
youtube$timetotrend <- youtube$trending_date - as.Date(youtube$publish_time)
youtube$timetotrend <- as.factor(ifelse(youtube$timetotrend <= 7, youtube$timetotrend, "8+"))
table(youtube$timetotrend)
gi1 <- data.frame(table(youtube$category))
library(ggplot2)
ggplot(gi1, aes(x=reorder(Var1, -Freq), y=Freq)) +
  geom_segment( aes(x=reorder(Var1, Freq), xend=reorder(Var1, Freq), y=0, yend=Freq), color="skyblue") +
  geom_point( color="blue", size=4, alpha=0.6) +
  theme_light() +
  coord_flip() +
  theme(
    panel.grid.major.y = element_blank(),
    panel.border = element_blank(),
    axis.ticks.y = element_blank()
  ) +
  labs(title = "Frequency of Trending Videos", 
       subtitle = "Based on Categories",
       caption = "Source : Youtube Trending Dataset", 
       x = "Category",
       y = "Number of Videos")
